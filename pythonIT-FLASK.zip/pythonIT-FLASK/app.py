def calc(a, b):
    return a + b


def divide(a, b):
    if b == 0:
        raise ValueError("Деление на ноль невозможно")
    return a / b
